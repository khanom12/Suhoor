# Subh AI Weather Cloud Assets — Top Hero Parallax Pack v1

This pack replaces the earlier procedural/code-generated cloud textures with image-generator-derived cloud imagery that has been cropped, cleaned, alpha-extracted, and rebuilt as synchronized transparent asset layers for the Subh home screen.

## Purpose

Create a realistic, iOS Weather-like atmospheric cloud effect behind the Subh hero area.

The effect should appear only near the upper/home hero section. It should not place visible cloud content down the full page.

## Required Visual Stack

Use this order in `SubhHomeView.swift`:

```swift
AppPageBackground()
    .ignoresSafeArea()

AppAtmosphericCloudLayer()
    .ignoresSafeArea()
    .allowsHitTesting(false)
    .accessibilityHidden(true)

AppHomeContrastOverlay()
    .ignoresSafeArea()
```

Do not place the clouds above `AppHomeContrastOverlay()`. They must sit behind the tint so they feel embedded in the dawn background rather than floating over the UI.

## Asset Set

All five assets share the same transparent top-hero canvas size and coordinate system:

- 1x: 1024 × 512 px
- 2x: 2048 × 1024 px
- 3x: 3072 × 1536 px

Copy these `.imageset` folders into:

`Subh/Resources/Assets.xcassets/`

| Depth | Asset | Motion | Suggested loop | Role |
|---:|---|---|---:|---|
| 0 | `SubhDawnHeroCloudMist` | slowest / almost static | 290s | far atmospheric haze |
| 1 | `SubhDawnHeroCloudFar` | slow | 235s | distant high wisps |
| 2 | `SubhDawnHeroCloudMid` | moderate | 168s | mid-depth cloud band |
| 3 | `SubhDawnHeroCloudLow` | faster | 116s | closer lower cloud layer |
| 4 | `SubhDawnHeroCloudNear` | fastest | 78s | nearest foreground wisps |

The motion relationship is intentional:

`Near fastest → Low → Mid → Far → Mist slowest`

This is the realism cue observed in the iOS Weather app: closer atmospheric material appears to drift faster than distant material.

## Top-Hero Concentration Rule

The cloud component should render only in the top portion of the screen, approximately the hero region.

Recommended runtime frame:

```swift
let heroCloudHeight = min(max(geometry.size.height * 0.40, 320), 430)
```

Then place the cloud layer at the top and allow the rest of the screen to remain clear:

```swift
VStack(spacing: 0) {
    cloudStack
        .frame(height: heroCloudHeight)
        .clipped()
    Spacer(minLength: 0)
}
```

Do not stretch the cloud effect down the full scroll view.

## Implementation Reference

Use:

`SampleIntegration/AppAtmosphericCloudLayer.sample.swift`

as the implementation reference.

## Accessibility

- Decorative only.
- `allowsHitTesting(false)`.
- `accessibilityHidden(true)`.
- Respect `accessibilityReduceMotion`.
- When Reduce Motion is enabled, freeze movement using deterministic phase offsets; do not remove the cloud layer entirely.

## Scope Guard

Do not modify:

- alarm scheduling
- Fajr/suhoor calculation
- wake modes
- hero state logic
- cards/charts
- settings
- notification/AlarmKit logic
- persistence/data models

Only add the assets and the decorative background layer.
