# Codex Integration Task — Subh AI Weather Cloud Assets

Use the attached asset pack:

`subh_ai_weather_cloud_assets_top_hero_v1.zip`

This package supersedes the earlier procedural/code-generated cloud assets.

## Steps

1. Unzip the package.
2. Copy every `.imageset` folder from:

   `subh_ai_weather_cloud_assets_top_hero_v1/Assets.xcassets/`

   into:

   `Subh/Resources/Assets.xcassets/`

3. Create:

   `Subh/UI/Components/AppAtmosphericCloudLayer.swift`

   using the implementation reference in:

   `SampleIntegration/AppAtmosphericCloudLayer.sample.swift`

4. Modify `Subh/Features/Home/SubhHomeView.swift` only as needed to insert the cloud layer between:

   `AppPageBackground()`

   and:

   `AppHomeContrastOverlay()`

## Required Layer Order

```swift
AppPageBackground()
    .ignoresSafeArea()

AppAtmosphericCloudLayer()
    .ignoresSafeArea()

AppHomeContrastOverlay()
    .ignoresSafeArea()
```

## Requirements

- Clouds must only appear in the upper/top hero area.
- They must not extend down the full screen.
- Keep the existing background image.
- Keep the existing contrast/tint overlay.
- Keep the clouds behind the contrast/tint overlay.
- Use parallax motion:
  - Mist: slowest, 290s
  - Far: 235s
  - Mid: 168s
  - Low: 116s
  - Near: fastest, 78s
- Respect Reduce Motion by freezing offsets.
- Decorative only: no hit testing, no accessibility focus.
- Do not modify unrelated app behavior.

## Commit Message

`Add AI-generated top-hero parallax cloud assets`
