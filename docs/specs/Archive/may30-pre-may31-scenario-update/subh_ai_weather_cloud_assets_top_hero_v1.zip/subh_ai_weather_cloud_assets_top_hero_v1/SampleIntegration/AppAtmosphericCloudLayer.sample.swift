import SwiftUI

/// Decorative atmospheric cloud layer for the Subh home background.
///
/// Intended layer order:
/// 1. AppPageBackground()
/// 2. AppAtmosphericCloudLayer()
/// 3. AppHomeContrastOverlay()
/// 4. Foreground content
struct AppAtmosphericCloudLayer: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    private let layers: [AtmosphericCloudLayer] = [
        .init(assetName: "SubhDawnHeroCloudMist", duration: 290, opacity: 0.16, widthMultiplier: 1.45, phaseOffset: 0.08, yOffset: -18, blurRadius: 5),
        .init(assetName: "SubhDawnHeroCloudFar", duration: 235, opacity: 0.24, widthMultiplier: 1.52, phaseOffset: 0.31, yOffset: -12, blurRadius: 2),
        .init(assetName: "SubhDawnHeroCloudMid", duration: 168, opacity: 0.26, widthMultiplier: 1.58, phaseOffset: 0.57, yOffset: -4, blurRadius: 1),
        .init(assetName: "SubhDawnHeroCloudLow", duration: 116, opacity: 0.23, widthMultiplier: 1.66, phaseOffset: 0.19, yOffset: 3, blurRadius: 0),
        .init(assetName: "SubhDawnHeroCloudNear", duration: 78, opacity: 0.18, widthMultiplier: 1.74, phaseOffset: 0.73, yOffset: 8, blurRadius: 0)
    ]

    var body: some View {
        GeometryReader { geometry in
            let heroCloudHeight = min(max(geometry.size.height * 0.40, 320), 430)

            VStack(spacing: 0) {
                TimelineView(.animation) { timeline in
                    ZStack {
                        ForEach(layers) { layer in
                            movingLayer(
                                layer,
                                containerWidth: geometry.size.width,
                                containerHeight: heroCloudHeight,
                                date: timeline.date
                            )
                        }
                    }
                    .frame(width: geometry.size.width, height: heroCloudHeight, alignment: .top)
                    .clipped()
                    .mask(alignment: .top) {
                        LinearGradient(
                            stops: [
                                .init(color: .white.opacity(0.95), location: 0.00),
                                .init(color: .white.opacity(1.00), location: 0.62),
                                .init(color: .white.opacity(0.00), location: 1.00)
                            ],
                            startPoint: .top,
                            endPoint: .bottom
                        )
                    }
                }

                Spacer(minLength: 0)
            }
        }
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }

    private func movingLayer(
        _ layer: AtmosphericCloudLayer,
        containerWidth: CGFloat,
        containerHeight: CGFloat,
        date: Date
    ) -> some View {
        let tileWidth = max(containerWidth * layer.widthMultiplier, containerWidth + 1)
        let progress = reduceMotion
            ? layer.phaseOffset
            : ((date.timeIntervalSinceReferenceDate / layer.duration) + layer.phaseOffset)
                .truncatingRemainder(dividingBy: 1)
        let xOffset = -tileWidth * progress

        return HStack(spacing: 0) {
            ForEach(0..<3, id: \.self) { _ in
                Image(layer.assetName)
                    .resizable()
                    .scaledToFill()
                    .frame(width: tileWidth, height: containerHeight, alignment: .top)
                    .clipped()
            }
        }
        .frame(width: tileWidth * 3, height: containerHeight, alignment: .leading)
        .offset(x: xOffset - tileWidth, y: layer.yOffset)
        .opacity(layer.opacity)
        .blur(radius: layer.blurRadius)
        .compositingGroup()
    }
}

private struct AtmosphericCloudLayer: Identifiable {
    let id = UUID()
    let assetName: String
    let duration: TimeInterval
    let opacity: Double
    let widthMultiplier: CGFloat
    let phaseOffset: Double
    let yOffset: CGFloat
    let blurRadius: CGFloat
}
